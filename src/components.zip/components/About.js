import "./About.css";
import profilePic from "../about-profile.jpg"; // Update this path if needed

const About = () => {
  return (
    <section id="about" className="about-section">
      <div className="about-container">
        <div className="about-image">
          <img src={profilePic} alt="Profile" className="profile-pic" />
        </div>
        <div className="about-text">
          <h2>
            <span className="highlight">About Me</span> <span className="emoji">🌸</span>
          </h2>
          <p>
            Hey there! 👋 Thanks for scrolling down this far. I'm a passionate developer who loves building
            interactive, clean web experiences. This portfolio may not be brand new, but it’s still full of my spirit! 💻✨
          </p>
          <p>
            When I’m not coding, you’ll find me playing Animal Crossing 🎮, binge-reading novels 📚, or exploring new tech trends. 
            I’m always up for new book or game recommendations, so feel free to reach out!
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
